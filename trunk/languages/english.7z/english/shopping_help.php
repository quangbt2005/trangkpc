<?php
/*
 * Created on Apr 5, 2010
 *
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */
 define('HEADING_TITLE', 'SHOPPING HELP');
 define('TEXT_SHOPPING_HELP_INFORMATION', 'help');
?>
